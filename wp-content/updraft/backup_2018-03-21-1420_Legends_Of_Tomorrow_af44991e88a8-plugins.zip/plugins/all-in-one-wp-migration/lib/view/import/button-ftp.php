<a href="https://servmask.com/products/ftp-extension" target="_blank"><?php _e( 'FTP', AI1WM_PLUGIN_NAME ); ?></a>
